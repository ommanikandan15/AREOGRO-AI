import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Animated } from 'react-native';

interface ModeToggleProps {
  mode: 'organic' | 'natural';
  setMode: (mode: 'organic' | 'natural') => void;
}

export default function ModeToggle({ mode, setMode }: ModeToggleProps) {
  const isOrganic = mode === 'organic';
  const translateX = new Animated.Value(isOrganic ? 0 : 1);

  // animate on mode change
  React.useEffect(() => {
    Animated.timing(translateX, {
      toValue: isOrganic ? 0 : 1,
      duration: 200,
      useNativeDriver: true,
    }).start();
  }, [mode]);

  const toggle = () => setMode(isOrganic ? 'natural' : 'organic');

  const interpolated = translateX.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '50%'],
  });

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.toggleArea} onPress={toggle} activeOpacity={0.8}>
        <Animated.View style={[styles.thumb, { transform: [{ translateX: interpolated }] }]} />
        <View style={styles.labels} pointerEvents="none">
          <Text style={[styles.label, isOrganic && styles.activeLabel]}>Organic</Text>
          <Text style={[styles.label, !isOrganic && styles.activeLabel]}>Natural</Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  toggleArea: {
    width: '100%',
    height: 40,
    borderRadius: 20,
    backgroundColor: '#111',
    flexDirection: 'row',
    overflow: 'hidden',
    position: 'relative',
  },
  thumb: {
    position: 'absolute',
    width: '50%',
    height: '100%',
    backgroundColor: '#00ff00', // neon‑green active background
    borderRadius: 20,
  },
  labels: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
    zIndex: 1,
  },
  label: {
    color: '#888',
    fontWeight: '600',
  },
  activeLabel: {
    color: '#fff',
  },
});
