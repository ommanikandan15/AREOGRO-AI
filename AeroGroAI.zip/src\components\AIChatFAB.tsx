import React from 'react';
import { TouchableOpacity, StyleSheet, View, Text } from 'react-native';
import { MaterialIcons } from '@expo/vector-icons';

export default function AIChatFAB() {
  const handlePress = () => {
    // Placeholder: open chat overlay or navigate to AI chat screen
    console.log('AI Chat FAB pressed');
  };

  return (
    <View style={styles.container} pointerEvents="box-none">
      <TouchableOpacity style={styles.fab} onPress={handlePress} activeOpacity={0.8}>
        <MaterialIcons name="chat" size={24} color="#000" />
        <Text style={styles.label}>AI</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 30,
    right: 30,
    // ensure FAB sits above other UI
    elevation: 8,
    zIndex: 100,
  },
  fab: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#00ff00', // neon‑green
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  label: {
    marginLeft: 6,
    color: '#000',
    fontWeight: '600',
  },
});
