import React from 'react';
import { View, StyleSheet, Dimensions } from 'react-native';

interface SplitPanelProps {
  top: React.ReactNode;
  bottom: React.ReactNode;
  topRatio?: number; // proportion of height for top panel (0-1)
}

const SplitPanel: React.FC<SplitPanelProps> = ({ top, bottom, topRatio = 0.5 }) => {
  const { height } = Dimensions.get('window');
  const topHeight = height * topRatio;
  const bottomHeight = height - topHeight;
  return (
    <View style={styles.container}>
      <View style={[styles.panel, { height: topHeight }]}>{top}</View>
      <View style={[styles.panel, { height: bottomHeight, backgroundColor: '#0b0b1a' }]}>{bottom}</View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'column',
  },
  panel: {
    width: '100%',
  },
});

export default SplitPanel;
