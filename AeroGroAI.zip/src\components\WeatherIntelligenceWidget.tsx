import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface WeatherIntelligenceWidgetProps {
  mode: 'organic' | 'natural';
}

export default function WeatherIntelligenceWidget({ mode }: WeatherIntelligenceWidgetProps) {
  // Placeholder data - replace with real API calls
  const temperature = 28; // °C
  const precipitation = 12; // mm
  const priceIndex = mode === 'organic' ? 105 : 98; // mock index
  const riskLevel = priceIndex > 100 ? 'Orange' : 'Green'; // simple risk logic

  const riskColor = {
    Green: '#00ff00',
    Orange: '#ff8800',
    Red: '#ff0000',
  }[riskLevel as keyof typeof riskColor];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Weather & Market Intelligence</Text>
      <View style={styles.row}>
        <Text style={styles.label}>Temp:</Text>
        <Text style={styles.value}>{temperature}°C</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Precip:</Text>
        <Text style={styles.value}>{precipitation} mm</Text>
      </View>
      <View style={styles.row}>
        <Text style={styles.label}>Price Index:</Text>
        <Text style={styles.value}>{priceIndex}</Text>
        <View style={[styles.riskBadge, { backgroundColor: riskColor }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 12,
    backgroundColor: '#111',
    borderRadius: 8,
    marginTop: 12,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#00ff00',
    marginBottom: 8,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  label: {
    color: '#aaa',
    width: 100,
  },
  value: {
    color: '#fff',
    fontWeight: '500',
    marginRight: 8,
  },
  riskBadge: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
});
